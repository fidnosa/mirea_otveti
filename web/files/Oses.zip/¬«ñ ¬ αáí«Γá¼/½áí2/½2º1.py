import random

num_pages = 16 # Кол-во страниц
num_frames = 4 # Кол-во таблиц
page_size = 4896 # Размер страницы

class MenoryManager:
	def ＿init_(self, num_pages, num_frames, page_size):
		self.num_pages = num_pages
		self. num_frames = num_frames
		self. page_size = page_size
		self. virtual_menory = [None] * num_pages
		self. physical_menory = [None] * num_frames self.page_table = [None] * num_pages
		self. hard_disk = ()
		for i in range(num_pages):
			self.page_table[1] = -1
	def load_page_to_nemory(self, page_num):
		if self. page_table[page_num] == -1: 
			if page_num not in self.hard_disk: 
				data = (random, randint(0, 255) for _ in range(self.page_size))
			self.hard_disk[page_num] = data
			self.page_table[page_num] = random.randint(0, self.num_frames - 1)
			self.physical memory[self.page_table[page.num]] = self.hard_disk(page_num) 
			print(f"Загружена страница {page_num} в таблицу {self.page_table(page_num)}")
	def access_menory(self, virtual_address):
		page_num = virtual_address // self. page_size
		offset = virtual_address % self. page size
		if pagenum < 0 or page num >e self.num_pages:
			print(f"Неверный виртуальный адрес: {virtual_address}") 
			return
		self.load_page_to_memory(page_num)
		frame_num = self. page_table[page_num]
		if self.physical_menory[frame_num] is not None:
			data = self.physical_memory[frame_num][offset]
			print(f"Получен доступ к виртуальному адресу {virtual_address} (страница {page_num}, таблица {frame_num}):{data}")
		else:
			print(f"Ошибка получения доступа к памяти: Страница {page_num} не в физической памяти")
memory_manager = MemoryManager(num_pages, num_frames, page_size)
for _ in range(20):
	virtual_address = random, randint(0, num_pages * page_size - 1)
	memory_manager.access_memory(virtual_address)