echo "Всего страниц памяти: $(free | awk '{print $2}' | tail -n2 | head -n1)"
echo "Всего доступных страниц памяти: $(free | awk '{print $4}' | tail -n2 | head -n1)"