free -wtm
vmstat -w