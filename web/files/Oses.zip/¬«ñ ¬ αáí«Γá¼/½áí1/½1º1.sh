printf "PID -> $$\n"
printf "PPID -> $(ps -o ppid= -p $$)\n"