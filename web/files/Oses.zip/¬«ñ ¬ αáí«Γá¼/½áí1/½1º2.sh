printf "Current PID -> $$\n"
printf "For Program -> $1\n"
eval $1