THREADS_COUNT=4
for ((i = 1; i <= $THREADS_COUNT; i++))
do
printf "Запуск потока №$i\n"
( while true; do
printf "Поток №$i запущен\n"
sleep 1
done ) &
printf "Поток №$i завершен\n"
done
sleep 1
ps -T ax | grep "bash 3.sh" | awk '{print $1}' | head -n5 | xargs kill 
printf "Все потоки завершены\n"