﻿#include <iostream>
#include <string>
#include <codecvt>

int main() {
    std::string inputString;
    std::cout << "Enter a string: ";
    std::getline(std::cin, inputString);
    std::wstring_convert<std::codecvt_utf8<char32_t>, char32_t> converter;
    std::u32string unicodeString = converter.from_bytes(inputString);
    std::cout << "\nMethod 2 Output (Library): ";
    for (char32_t c : unicodeString) {
        std::cout << std::hex << c << " ";
    }
    return 0;
}