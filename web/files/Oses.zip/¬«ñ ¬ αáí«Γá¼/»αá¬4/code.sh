#!/bin/bash

#Задание 1
echo "1. Имя текущего каталога:"
pwd

echo "2. Смена текущего каталога:"
cd Documents

pwd

echo "3. Создание файла:"
touch testfile.txt

ls -l

echo "4. Предоставление прав на запись в файл:"
chmod +w testfile.txt

ls -l testfile.txt

echo "5. Удаление файла:"
rm testfile.txt

ls -l

echo "Задание 1 выполнено"
read -p "Нажмите Enter для продолжения" continue

#Задание 2

echo "1. Имя текущего каталога:"
pwd

echo "2. Содержимое текущего каталога:"
ls

echo "3. Создание каталога:"
mkdir testdir

ls

echo "4. Предоставление прав на запись в каталог:"
chmod -R 777 testdir

ls -l

echo "5. Создание символьной ссылки на файл:"
ln -s /etc/passwd userdata

ls -l userdata

read -p "Введите команду для выполнения:" cmd
eval $cmd

echo "7. Убрать всем право на запись в каталог:"
chmod -w testdir

ls -l

echo "Задание 2 выполнено"
read -p "Нажмите Enter для продолжения" continue
#Задание 3

echo -e "Имя каталога\tРазмер (байт)" > output.txt
for directory in $HOME/*; do
    if [ -d "$directory" ] && [ ! -h "$directory" ] && [ ! -f "$directory" ]; then
        dir_name=$(basename "$directory")
        dir_size=$(du -s "$directory" | awk '{print $1}')
        echo -e "$dir_name\t$dir_size" >> output.txt
    fi
done

cat output.txt
