input_dir="./input"
output_dir="./output"
result_file="result"

read -p "Выберите вариант (1 или 2): " choice

if [ "$choice" == "1" ]; then
    total_letters=$(cat "$input_dir"/* | tr -cd "[:alpha:]" | wc -c)
    echo "Общее количество букв: $total_letters" > "$output_dir/$result_file"

elif [ "$choice" == "2" ]; then
    total_digits=$(cat "$input_dir"/* | tr -cd "[:digit:]" | wc -c)
    echo "Общее количество цифр: $total_digits" > "$output_dir/$result_file"

else
    echo "Неверный номер варианта"
    exit 1
fi

printf "\nСписок прочитанных файлов:\n"
ls "$input_dir"

printf "\nИмя файла с результатами: $result_file\n"

printf "\nСодержимое файла с результатами $result_file:\n\n"
cat $output_dir/$result_file
