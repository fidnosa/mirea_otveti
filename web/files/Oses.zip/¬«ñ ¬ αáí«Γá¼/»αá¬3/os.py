class FileSystem:
    def __init__(self, capacity_kb=64, block_size=512):
        self.capacity_bytes = capacity_kb * 1024
        self.block_size = block_size
        self.file_system = {}

    def create_file(self, file_name, content=""):
        if file_name in self.file_system:
            print(f"Файл {file_name} уже существует")
            return
        if len(content) * 8 > self.capacity_bytes:
            print("Недостаточно места в файловой системе")
            return

        self.file_system[file_name] = content
        print(f"Файл {file_name} создан")

    def delete_file(self, file_name):
        if file_name in self.file_system:
            del self.file_system[file_name]
            print(f"Файл {file_name} удалён")
        else:
            print(f"Файл {file_name} не найден")

    def copy_file(self, source_file, destination_file):
        if source_file in self.file_system:
            self.file_system[destination_file] = self.file_system[source_file]
            print(f"Файл {source_file} скопирован в {destination_file}")
        else:
            print(f"Файл {source_file} не найден")

    def move_file(self, source_file, destination_file):
        if source_file in self.file_system:
            self.file_system[destination_file] = self.file_system.pop(source_file)
            print(f"Файл {source_file} перемещён {destination_file}")
        else:
            print(f"Файл {source_file} не найден")

    def rename_file(self, old_name, new_name):
        if old_name in self.file_system:
            self.file_system[new_name] = self.file_system.pop(old_name)
            print(f"Файл {old_name} переименован в {new_name} успешно")
        else:
            print(f"Файл {old_name} не найден")

    def display_file_system(self):
        for item, content in self.file_system.items():
            print(f"{item}")

    def display_memory_info(self):
        used_memory = sum(len(content) for content in self.file_system.values()) * 8
        free_memory = self.capacity_bytes - used_memory
        print(f"Используемая память: {used_memory} байтов")
        print(f"Доступная память: {free_memory} байтов")

file_system = FileSystem()

# file_system.create_file("file1", "This is the content of file1.")
# file_system.create_file("file2", "This is the content of file2.")
# file_system.display_file_system()

# file_system.copy_file("file1", "file3")
# file_system.display_file_system()

# file_system.move_file("file2", "dir1/file2")
# file_system.display_file_system()

# file_system.rename_file("file3", "file_new")
# file_system.display_file_system()

# file_system.delete_file("file1")
# file_system.display_file_system()

class Terminal:
    def __init__(self):
        self.file_system = FileSystem()

    def run(self):
        while True:
            try:
                command = input("\nВведите команду (help для вывода доступных команд)\nuser@pseudo_bash:$ > ").strip().split()
            except KeyboardInterrupt:
                print("\n\nВыход")
                exit()
            if not command:
                continue
            action = command[0].lower()
            if action == 'help':
                self.display_help()
            elif action == 'exit':
                print("\n\nВыход")
                break
            elif action == 'ls':
                self.file_system.display_file_system()
            elif action == 'touch':
                self.create_file(command)
            elif action == 'rm':
                self.delete_file(command)
            elif action == 'cp':
                self.copy_file(command)
            elif action == 'mv':
                self.move_file(command)
            elif action == 'rename':
                self.rename_file(command)
            elif action == 'memory':
                self.file_system.display_memory_info()
            else:
                print("Введите команду help для вывода доступных команд")

    def create_file(self, command):
        if len(command) == 2:
            file_name = command[1]
            self.file_system.create_file(file_name)
        else:
            print("Использование:\ntouch <файл>")

    def delete_file(self, command):
        if len(command) == 2:
            file_name = command[1]
            self.file_system.delete_file(file_name)
        else:
            print("Использование:\nrm <файл>")

    def copy_file(self, command):
        if len(command) == 3:
            source_file = command[1]
            destination_file = command[2]
            self.file_system.copy_file(source_file, destination_file)
        else:
            print("Использование:\ncp <исх_файл> <конеч_файл>")

    def move_file(self, command):
        if len(command) == 3:
            source_file = command[1]
            destination_file = command[2]
            self.file_system.move_file(source_file, destination_file)
        else:
            print("Использование:\nmv <исх_файл> <конеч_файл>")

    def rename_file(self, command):
        if len(command) == 3:
            old_name = command[1]
            new_name = command[2]
            self.file_system.rename_file(old_name, new_name)
        else:
            print("Использование:\nrename <старое_имя> <новое_имя>")

    def display_help(self):
        print("Доступные команды:")
        print(" help                                   - Вывод доступных команд")
        print("")
        print(" exit или CTRL+C                        - Выход")
        print("")
        print(" ls                                     - Вывод информации о файлах")
        print("")
        print(" touch <файл>                           - Создать файл")
        print("")
        print(" rm <файл>                              - Удалить файл")
        print("")
        print(" cp <исх_файл> <конеч_файл>             - Скопировать файл")
        print("")
        print(" mv <исх_файл> <конеч_файл>             - Переместить файл")
        print("")
        print(" rename <старое_имя> <новое_имя>        - Переименовать файл")
        print("")
        print(" memory                                 - Вывод информации о памяти")

if __name__ == "__main__":
    terminal = Terminal()
    terminal.run()
