#!/bin/bash

read -p "Введите M -> " M
read -p "Введите N -> " N

calculate_sum() {
    start=$1
    end=$2
    sum=0
    for ((i = start; i <= end; i++)); do
        sum=$((sum + i))
    done
    echo "Поток $3 Числа $start $((end-2)) $((end-1)) $end сумма $sum"
}

segment_size=$((N / M))
start=1

for ((i = 0; i < M; i++)); do
    end=$((start + segment_size - 1))
    if [ $i -eq $((M-1)) ]; then
        end=$N
    fi
    calculate_sum $start $end $i &
    start=$((end + 1))
done

wait
