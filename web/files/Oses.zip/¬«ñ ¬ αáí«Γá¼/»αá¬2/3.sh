#!/bin/bash

worker_function() {
  while true; do
    echo "Запуск потока $1"
    sleep 1
  done
}

for i in {1..3}; do
  worker_function $i &
done

echo "Запущено 3 фоновых потока выполнения"

pause_workers() {
  for pid in $(jobs -p); do
    kill -SIGSTOP $pid
  done
  echo "Потоки приостановлены"
}

resume_workers() {
  for pid in $(jobs -p); do
    kill -SIGCONT $pid
  done
  echo "Потоки возобновлены"
}

while true; do
  read -p "Введите команду (pause/resume/exit) -> " command

  case "$command" in
    "pause")
      pause_workers
      ;;
    "resume")
      resume_workers
      ;;
    "exit")
      echo "Выход из программы"
      pause_workers
      exit 0
      ;;
    *)
      echo "Неверная команда. Доступные команды: pause, resume, exit"
      ;;
  esac
done
