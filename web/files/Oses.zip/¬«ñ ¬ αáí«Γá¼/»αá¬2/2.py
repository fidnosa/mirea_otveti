import threading
import random

def generate_matrix(rows, cols):
    return [[random.randint(1, 10) for _ in range(cols)] for _ in range(rows)]

def add_matrices(matrix1, matrix2):
    result = [[0 for _ in range(len(matrix1[0]))] for _ in range(len(matrix1))]
    for i in range(len(matrix1)):
        for j in range(len(matrix1[0])):
            result[i][j] = matrix1[i][j] + matrix2[i][j]
    return result

def single_threaded_addition(matrix1, matrix2):
    result = add_matrices(matrix1, matrix2)
    return result

M = int(input("Введите количество строк (M): "))
N = int(input("Введите количество столбцов (N): "))

if M < 0 or M > 1000 or N < 0 or N > 1000:
    print("Неверные значения столбца и/или строки")
    exit()

matrix1 = generate_matrix(M, N)
matrix2 = generate_matrix(M, N)

print("Первая матрица:")
for row in matrix1:
    print(row)

print("Вторая матрица:")
for row in matrix2:
    print(row)

single_thread_result = single_threaded_addition(matrix1, matrix2)
print("Результат сложения:")
for row in single_thread_result:
    print(row)
